import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateDividendModel, inferDividendInputs } from '../public/calc.js';

test('calculates annual, monthly, after-tax income, and yields', () => {
  const model = calculateDividendModel({
    investmentAmount: 10000,
    sharePrice: 50,
    dividendPerShare: 0.5,
    frequency: 'quarterly',
    taxRate: 15,
    fees: 0,
    projectionYears: 5,
    dividendGrowthRate: 0,
    priceGrowthRate: 0,
    recurringContribution: 0,
    reinvestDividends: false,
    allowFractionalShares: true
  });

  assert.equal(model.shares, 200);
  assert.equal(model.annualDividendPerShare, 2);
  assert.equal(model.annualIncome, 400);
  assert.equal(Math.round(model.monthlyIncome * 100) / 100, 33.33);
  assert.equal(model.afterTaxAnnualIncome, 340);
  assert.equal(model.yieldOnCost, 0.04);
  assert.equal(model.currentYield, 0.04);
});

test('respects whole-share mode and fees', () => {
  const model = calculateDividendModel({
    investmentAmount: 1000,
    sharePrice: 33,
    dividendPerShare: 1,
    frequency: 'annual',
    taxRate: 0,
    fees: 25,
    projectionYears: 1,
    dividendGrowthRate: 0,
    priceGrowthRate: 0,
    recurringContribution: 0,
    reinvestDividends: false,
    allowFractionalShares: false
  });

  assert.equal(model.inputs.availableInvestment, 975);
  assert.equal(model.shares, 29);
  assert.equal(model.annualIncome, 29);
});

test('projects reinvestment and monthly contributions', () => {
  const withoutDrip = calculateDividendModel({
    investmentAmount: 10000,
    sharePrice: 100,
    dividendPerShare: 1,
    frequency: 'quarterly',
    taxRate: 0,
    fees: 0,
    projectionYears: 10,
    dividendGrowthRate: 2,
    priceGrowthRate: 3,
    recurringContribution: 100,
    reinvestDividends: false,
    allowFractionalShares: true
  });

  const withDrip = calculateDividendModel({
    investmentAmount: 10000,
    sharePrice: 100,
    dividendPerShare: 1,
    frequency: 'quarterly',
    taxRate: 0,
    fees: 0,
    projectionYears: 10,
    dividendGrowthRate: 2,
    priceGrowthRate: 3,
    recurringContribution: 100,
    reinvestDividends: true,
    allowFractionalShares: true
  });

  assert.equal(withoutDrip.projection.length, 10);
  assert.ok(withDrip.projection.at(-1).shares > withoutDrip.projection.at(-1).shares);
  assert.ok(withDrip.projection.at(-1).grossIncome > withoutDrip.projection.at(-1).grossIncome);
});

test('infers quarterly dividend assumptions from recent history', () => {
  const inferred = inferDividendInputs([
    { amount: 0.45, exDividendDate: '2026-05-10' },
    { amount: 0.44, exDividendDate: '2026-02-10' },
    { amount: 0.43, exDividendDate: '2025-11-10' },
    { amount: 0.42, exDividendDate: '2025-08-10' }
  ]);

  assert.equal(inferred.frequency, 'quarterly');
  assert.equal(Math.round(inferred.annualDividend * 100), 174);
  assert.equal(Math.round(inferred.dividendPerShare * 10000), 4350);
});

test('builds monthly payout schedule', () => {
  const model = calculateDividendModel({
    investmentAmount: 1200,
    sharePrice: 12,
    dividendPerShare: 0.1,
    frequency: 'monthly',
    taxRate: 0,
    fees: 0,
    projectionYears: 1,
    dividendGrowthRate: 0,
    priceGrowthRate: 0,
    recurringContribution: 0,
    reinvestDividends: false,
    allowFractionalShares: true
  });

  assert.equal(model.payoutSchedule.length, 12);
  assert.equal(Math.round(model.annualIncome * 100), 12000);
  assert.equal(Math.round(model.payoutSchedule[0].amount * 100), 1000);
});
